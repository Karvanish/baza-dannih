# Выкладка 10 сайтов (сборка 29.10.2026)

Статические сайты: только HTML, CSS, JS, шрифты и картинки. На сервере нужен только nginx: без PHP, без базы данных, без внешних запросов.

## Что в архиве

```
www/<домен>/                         готовый сайт (корень для nginx), 10 папок
nginx/<домен>.conf                   server-блоки сайта: 80 → https, www → без www, сам сайт
nginx/redirects/<домен-с-дефисами>/redirects.map   карта редиректов (сейчас пустая; конфиг её подключает, файл обязателен)
indexnow/<домен>.json                список URL сайта для IndexNow (ключ уже лежит в корне сайта)
install.sh                           раскладывает файлы и конфиги (сертификаты и reload не трогает)
SHA256SUMS                           контрольные суммы всех файлов
```

Домены: betting-sites-in-kenya.com, online-betting-kenya.com, betting-apps-kenya.com, jackpot-predictions-kenya.com, betting-tips-kenya.com, betting-bonus-kenya.com, online-slots-kenya.com, live-casino-kenya.com, crash-games-kenya.com, new-betting-sites-kenya.com.

## 1. Распаковать и сверить

```bash
tar -xzf kenya-sites-2026-10-29.tar.gz
cd kenya-sites-2026-10-29
sha256sum -c SHA256SUMS --quiet && echo OK
```

## 2. Разложить файлы и конфиги

```bash
sudo ./install.sh
```

По умолчанию сайты кладутся в `/var/www/<домен>/`, конфиги в `/etc/nginx/conf.d/`, карты редиректов в `/etc/nginx/<домен-с-дефисами>/`. Если пути другие: `sudo WEBROOT=/srv/www CONF_DIR=/etc/nginx/sites-available ./install.sh` (тогда в конфигах `root` поправится сам, а для sites-available нужны симлинки в sites-enabled). Только часть сайтов: `sudo ./install.sh betting-tips-kenya.com crash-games-kenya.com`.

Вручную то же самое для одного домена:

```bash
d=betting-tips-kenya.com; s=${d//./-}
sudo mkdir -p /var/www/$d /etc/nginx/$s /var/www/_acme
sudo rsync -rc --delete --delay-updates www/$d/ /var/www/$d/
sudo cp nginx/redirects/$s/redirects.map /etc/nginx/$s/redirects.map
sudo cp nginx/$d.conf /etc/nginx/conf.d/$d.conf
```

## 3. Сертификаты (домен и www)

Конфиги ждут сертификат по пути `/etc/letsencrypt/live/<домен>/fullchain.pem` и `privkey.pem`. Пока файлов нет, `nginx -t` не пройдёт, поэтому сертификаты выпускаются до reload.

- **Let's Encrypt, nginx ещё не слушает 80 порт:** `sudo certbot certonly --standalone -d <домен> -d www.<домен>` для каждого домена.
- **Let's Encrypt, nginx уже работает:** временно уберите конфиг сайта из conf.d (или выпустите всё через DNS-проверку), выпустите сертификат, верните конфиг. После первой выдачи продление идёт через `--webroot -w /var/www/_acme`: в конфигах для этого открыт путь `/.well-known/acme-challenge/` на 80 порту.
- **Сайты за Cloudflare (режим Full strict):** можно поставить Origin Certificate. Положите файлы куда удобно и замените два пути `ssl_certificate` / `ssl_certificate_key` в двух server-блоках на 443 каждого конфига.

## 4. За CDN: настоящий IP посетителя

Если сайты стоят за Cloudflare или другим CDN, раскомментируйте в каждом конфиге блок `set_real_ip_from` / `real_ip_header` и впишите актуальные диапазоны CDN (у Cloudflare: cloudflare.com/ips). Без этого в логах будут IP CDN; на работу сайтов это не влияет.

## 5. Проверить и включить

```bash
sudo nginx -t && sudo systemctl reload nginx
```

На nginx 1.25.1 и новее `nginx -t` предупредит, что `listen ... http2` устарел. Это предупреждение, не ошибка; при желании замените в конфигах `listen 443 ssl http2;` на `listen 443 ssl;` плюс строку `http2 on;`.

## 6. Проверка после выкладки (для каждого домена)

```bash
d=betting-tips-kenya.com
curl -sI https://$d/ | head -1                       # 200
curl -sI http://$d/ | grep -i location               # https://$d/
curl -sI https://www.$d/ | grep -i location          # https://$d/
curl -sI https://$d/index.html | head -1             # 301
curl -sI https://$d/no-such-page/ | head -1          # 404
for f in robots.txt sitemap.xml llms.txt; do curl -s -o /dev/null -w "$f %{http_code}\n" https://$d/$f; done   # 200
```

## 7. Индексация

- Google Search Console и Bing Webmaster Tools: добавить каждый домен и отправить `https://<домен>/sitemap.xml`.
- IndexNow (Bing, Yandex и др.), один запрос на домен:

```bash
for j in indexnow/*.json; do
  curl -s -o /dev/null -w "$(basename $j .json) %{http_code}\n" -X POST https://api.indexnow.org/indexnow \
    -H 'Content-Type: application/json; charset=utf-8' --data @"$j"
done
```

Ответ 200 или 202 означает, что запрос принят. Отправлять только после того, как сайт открывается по https: поисковик проверит ключ по адресу `https://<домен>/<ключ>.txt`.

## Что важно знать

- Режим всех сайтов DEMO: нет партнёрских ссылок, рейтингов, бонусов и аналитики. Подключение аналитики и данные издателя описаны в `docs/README.ru.md` репозитория (раздел 5).
- Новые статьи: этот архив только про текущие сайты. Чтобы серверный агент писал и публиковал статьи, на сервер нужен сам репозиторий `kenya-network` (платформа, контент, шаблоны); порядок работы агента в `docs/README.ru.md`, раздел 3. После каждой публикации папка `sites/<домен>/site/` синхронизируется в `/var/www/<домен>/` той же командой rsync.
- Ссылки на сайт ODPC (odpc.go.ke) в 12 статьях 29.10 не открывались: сайт регулятора целиком отдавал 404. Стоит проверить их через несколько дней.

#!/usr/bin/env bash
# Puts the 10 static sites and their nginx configs in place.
# It does NOT issue certificates and does NOT reload nginx: do those yourself (see DEPLOY.md).
#
# Usage (as root, from the unpacked folder):
#   ./install.sh                     # all 10 sites
#   ./install.sh betting-tips-kenya.com crash-games-kenya.com   # only these
# Options via environment:
#   WEBROOT=/var/www            where site folders go (default /var/www)
#   CONF_DIR=/etc/nginx/conf.d  where the server blocks go (Debian/Ubuntu: conf.d or sites-available + symlink)
#   NGINX_DIR=/etc/nginx        where the per-site redirects.map folders go
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
WEBROOT="${WEBROOT:-/var/www}"
CONF_DIR="${CONF_DIR:-/etc/nginx/conf.d}"
NGINX_DIR="${NGINX_DIR:-/etc/nginx}"
command -v rsync >/dev/null || { echo "rsync is required (apt install rsync)"; exit 1; }

if [ "$#" -gt 0 ]; then DOMAINS=("$@"); else DOMAINS=(); for d in "$HERE"/www/*/; do DOMAINS+=("$(basename "$d")"); done; fi

mkdir -p "$WEBROOT/_acme" "$CONF_DIR"
for d in "${DOMAINS[@]}"; do
  [ -d "$HERE/www/$d" ] || { echo "unknown domain: $d"; exit 1; }
  slug="${d//./-}"
  mkdir -p "$WEBROOT/$d" "$NGINX_DIR/$slug"
  # site files: replace the folder contents with this build (files that are not in the build are removed)
  rsync -rc --delete --delay-updates "$HERE/www/$d/" "$WEBROOT/$d/"
  # redirect map: required by the config; keep an existing one if you already edited it
  [ -f "$NGINX_DIR/$slug/redirects.map" ] || cp "$HERE/nginx/redirects/$slug/redirects.map" "$NGINX_DIR/$slug/redirects.map"
  # server block
  cp "$HERE/nginx/$d.conf" "$CONF_DIR/$d.conf"
  if [ "$NGINX_DIR" != "/etc/nginx" ]; then
    sed -i.bak "s#include /etc/nginx/$slug/redirects.map;#include $NGINX_DIR/$slug/redirects.map;#" "$CONF_DIR/$d.conf" && rm -f "$CONF_DIR/$d.conf.bak"
  fi
  if [ "$WEBROOT" != "/var/www" ]; then
    sed -i.bak -e "s#root /var/www/$d;#root $WEBROOT/$d;#" -e "s#root /var/www/_acme;#root $WEBROOT/_acme;#" "$CONF_DIR/$d.conf" && rm -f "$CONF_DIR/$d.conf.bak"
  fi
  echo "ok  $d  ->  $WEBROOT/$d , $CONF_DIR/$d.conf"
done
echo
echo "Next: certificates for each domain and www (DEPLOY.md, step 3), then:  nginx -t && systemctl reload nginx"
